<?php
$cn= new mysqli("localhost","root","","quiz_new") or die("Could not Connect");
//mysql_select_db("quiz_new",$cn)  or die("Could connect to Database");
?>
